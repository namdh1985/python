from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

#127.0.0.1:5000/hello
@app.route('/hello')
def hello():
    return jsonify({'message': 'Hello'})

productList = [
    {'code': 'IPX', 'name': 'Iphone X', 'price': 17.5},
    {'code': 'IP8', 'name': 'Iphone 8', 'price': 12.5},
    {'code': 'IP7', 'name': 'Iphone 7', 'price': 7.5},
]

#127.0.0.1:5000/api/search_product?keyword=IPX
@app.route('/api/search_product')
def searchProduct():
    keyword = request.args.get('keyword', '')
    result = [product for product in productList
                    if keyword in product['name']
                    or keyword in product['code']]
                    
    return jsonify({'productList': result})

#127.0.0.1:5000
@app.route('/')
def index():
    return render_template('index.html')

app.run(debug=True)    

